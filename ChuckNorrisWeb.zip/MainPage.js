let moviesData;

function initializePage() {
    loadMovies();
    loadRandomImage();
    getJoke(); // Load a joke on page load
}

function loadMovies() {
    let moviesJSON = '{"movies": [ ' +
        '{"title": "Way of the Dragon", "year": 1972, "role": "Colt"}, ' +
        '{"title": "Good Guys Wear Black", "year": 1978, "role": "John T. Booker"}, ' +
        '{"title": "The Octagon","year": 1980,"role": "Scott James"},' +
        '{"title": "Lone Wolf McQuade","year": 1983,"role": "J.J. McQuade"},' +
        '{"title": "Missing in Action","year": 1984,"role": "Colonel James Braddock"}' +
      ']}'
    
    moviesData = JSON.parse(moviesJSON).movies;
    displayMovies(moviesData);
}

function displayMovies(movies) {
    let tableBody = document.getElementById("moviesTableBody");
    tableBody.innerHTML = "";
    movies.forEach((movie, index) => {
        let row = `<tr style="background-color: ${index % 2 === 0 ? '#f2f2f2' : '#ffffff'};"><td>${movie.title}</td><td>${movie.year}</td><td>${movie.role}</td></tr>`;
        tableBody.innerHTML += row;
    });
}

function filterMovies() {
    let year = parseInt(document.getElementById("yearFilter").value);
    if (isNaN(year) || year.toString().length !== 4) {
        alert("Please enter a valid 4-digit year.");
        return;
    }
    let filteredMovies = moviesData.filter(movie => movie.year >= year);
    displayMovies(filteredMovies);
}

function loadRandomImage() {
    let images = [
        "https://media.gettyimages.com/id/2163427681/photo/lacteur-am%C3%A9ricain-chuck-norris-fait-la-promotion-du-film-pumping-iron-a-taormina-le-24.jpg?s=612x612&w=0&k=20&c=wNgrN5WrROcefkKa0WtaMHU7CJykFTDT4Gkssq9c5Sk=",
        "https://m.media-amazon.com/images/M/MV5BMTM1OTUwNjA3OF5BMl5BanBnXkFtZTcwMzQxODc3Nw@@._V1_QL75_UX326_.jpg",
        "https://m.media-amazon.com/images/M/MV5BNTk4NDA3MDU2OV5BMl5BanBnXkFtZTcwNjYzMDU4Mg@@._V1_QL75_UX334_.jpg",
        "https://media.gettyimages.com/id/163063331/photo/chuck-norris-in-hero-and-the-terror.jpg?s=2048x2048&w=gi&k=20&c=TguKa2zImJK1-UjBFIZgQPvNKxMH7JMSYZHC0Be8g68="
    ];
    let randomIndex = Math.floor(Math.random() * images.length);
    document.getElementById("chuckImage").src = images[randomIndex];
}

async function getJoke() {
    let response = await fetch("https://api.chucknorris.io/jokes/random");
    let data = await response.json();
    let jokeContainer = document.getElementById("jokeContainer");
    jokeContainer.innerText = data.value;

    document.getElementById("likeJoke").disabled = false;
    document.getElementById("dislikeJoke").disabled = false;
    document.getElementById("clearJoke").disabled = false;
}

function likeJoke() {
    document.getElementById("jokeContainer").style.color = "green";
}

function dislikeJoke() {
    document.getElementById("jokeContainer").style.color = "red";
}

function clearJoke() {
    document.getElementById("jokeContainer").innerText = "";
    document.getElementById("likeJoke").disabled = true;
    document.getElementById("dislikeJoke").disabled = true;
    document.getElementById("clearJoke").disabled = true;
}